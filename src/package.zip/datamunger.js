exports.munge = async (event, context) => {
    console.log('yep');
}